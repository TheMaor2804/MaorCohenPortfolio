import { createCardList } from "./dombuilder.js";

createCardList();