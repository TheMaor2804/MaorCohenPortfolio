import { build } from "./domBuilder.js";



build();






